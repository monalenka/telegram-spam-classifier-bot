import csv

input_txt = 'ham.txt' 
output_csv = 'ham.csv'

with open(input_txt, 'r', encoding='utf-8') as infile, \
     open(output_csv, 'w', encoding='utf-8', newline='') as outfile:
    writer = csv.writer(outfile)
    for line in infile:
        line = line.strip()
        if line:
            writer.writerow([line])
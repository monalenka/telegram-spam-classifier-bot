import re
from docx import Document
import csv
import random

input_docx = "spam_with_spaces.docx"
output_csv = "spam.csv"

try:
    doc = Document(input_docx)
except Exception as e:
    print(f"Ошибка при открытии файла: {e}")
    exit(1)

cleaned_lines = []
for p in doc.paragraphs:
    line = p.text.strip()
    line = line.replace('*', '')
    line = line.replace(';', '')
    if len(line) < 5:
        continue
    if re.match(r'^[-—]', line):
        continue
    cleaned_lines.append([line])

random.shuffle(cleaned_lines)

with open(output_csv, 'w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(cleaned_lines)

print(f"Очищено и сохранено строк: {len(cleaned_lines)} в {output_csv}")